#pragma once

#include <iostream>
#include <iomanip>
#include <sstream>
#include <limits>
#include <string>
#include "List.h"
#include "FileIO.h"
#include "MainStorage.h"
#include "SearchResult.h"

/**
@class CommandLineUI
contains the presentational and interactive interface in the command line for the user.\n
KEEP ALL COUT<< AND CIN>> HERE
*/

class CommandLineUI
{
private:
	static const unsigned int resultsMax = 3;
	static unsigned int operationsTotal, operationsInsert, operationsFind, operationsDelete;
	static std::string initialFilePath;
	static MainStorage* mainStoragePtr;
public:
	static void enterLoop ();
	static void importFile ();
	static void fileExport ();
	static void nameSearch ();
	static void fatSearch ();
	static void carbSearch ();
	static void addfood ();
	static void deletefood ();
	static void updatefood();
	static void findfood ();

	static void printfoodnameBST ();
	
	static void HashMapStats ();
	static void efficiencyStats();
	static void HashMapTest ();
	static void listname();

	static void addResultHelper (SearchResult<List<MainStorageNode*>*>* searchResultPtr);
	static void searchResultHelper (SearchResult<List<MainStorageNode*>*>* searchResultPtr);
	static void deleteResultHelper(SearchResult<List<MainStorageNode*>*>* searchResultPtr);

	static void visitImport(MainStorageNode* foodNodePtr);
	static void visitImportDot(MainStorageNode* foodNodePtr);
	static void visitExport(MainStorageNode* foodNodePtr);
	static void visitExportDot(MainStorageNode* foodNodePtr);
	static std::string visitname(MainStorageNode* foodNodePtr);

	static std::string timeSecondFormat(unsigned int microSeconds);
};


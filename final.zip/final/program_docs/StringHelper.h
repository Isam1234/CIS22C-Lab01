#ifndef STRING_HELPER_H
#define STRING_HELPER_H

#include <string>
#include <locale>
#include "List.h"

/**
@class StringHelper
A collection of static string manipulating methods
*/
class StringHelper
{
public:
	static List<std::string>* split(std::string target, std::string delim);
	static std::string join(List<std::string>* target, std::string delim);

	static std::string toID(std::string name, int calorie);

	static std::string sanitize(std::string str, char replace);
	static std::string sanitize255(std::string str);

	static void replaceAll(std::string& str, const std::string& from, const std::string& to);

	static std::string toLower(std::string str);
	static unsigned int hashStr(std::string str, unsigned int size);
	static std::string center(std::string str, unsigned int size);
	static std::string repeatToLength(std::string s, unsigned len);
	static bool isNumeric(std::string str);
	static std::string trim(const std::string& str, const std::string& whitespace);
	static std::string reduce(const std::string& str, const std::string& fill, const std::string& whitespace);

	static void reduce(List<std::string>* target);
};
#endif
#include "MainStorage.h"

MainStorage::MainStorage()
{
	storageMap = new HashMap <MainStorageNode*>(maxItems);
	idBST = new BST<int, MainStorageNode>;
	nameBriefBST = new BST<std::string, MainStorageNode>;
	nameFullBST = new BST<std::string, MainStorageNode>;
	nameBST = new BST<std::string, MainStorageNode>*[nameIndexes];
	for (int i = 0; i < nameIndexes; i++)
		nameBST[i] = new BST<std::string, MainStorageNode>;
	calorieBST = new BST<int, MainStorageNode>;
	fatBST = new BST<double, MainStorageNode>;
	carbBST = new BST<std::string, MainStorageNode>*[carbSize];
	for (int i = 0; i < carbSize; i++)
		carbBST[i] = new BST<std::string, MainStorageNode>;
	/* nodes in the map */
	itemCount = 0;
	operationsTotal = operationsInsert = operationsFind = operationsDelete = 0;
}

unsigned int MainStorage::size() const
{
	return storageMap->size();
}

std::string MainStorage::insert(std::string name, int calorie, double fat, std::string protein, unsigned int &operations)
{
	return insert(new MainStorageNode(name, calorie, fat, protein), operations);
}

std::string MainStorage::insert(MainStorageNode* nodePtr, unsigned int &operations)
{
	unsigned int i, n, n1, n2;
	int pos; // may be -1 for not found
	std::string foodKey = StringHelper::toID(nodePtr->getname(), nodePtr->getcalorie());
	pos = storageMap->find(foodKey, operations);
	if (pos < 0)
	{
		storageMap->insert(foodKey, nodePtr, operations);
		idBST->add(nodePtr, MainStorage::accessId, operations);
		nameFullBST->add(nodePtr, MainStorage::accessnameFull, operations);
		List<std::string>* nameListPtr = nodePtr->getnameList();
		n1 = nameListPtr->size();
		n = (nameIndexes < n1 ? nameIndexes : n1);
		if (n1 > 0) {
			nameBriefBST->add(nodePtr, MainStorage::accessnameBrief, operations);
		}
		for (i = 0; i < n; i++)
		{
			nameBST[i]->add(nodePtr, MainStorage::accessnameList(i), operations);
		}
		calorieBST->add(nodePtr, MainStorage::accesscalorie, operations);
		fatBST->add(nodePtr, MainStorage::accessfat, operations);
		List<std::string>* carbListPtr = nodePtr->getcarbList();
		n2 = carbListPtr->size();
		n = (carbSize < n2 ? carbSize : n2);
		for (i = 0; i < n; i++)
			carbBST[i]->add(nodePtr, MainStorage::accesscarb(i), operations);
	}
	operationsTotal += operations;
	operationsInsert += operations;
	return foodKey;
}

bool MainStorage::remove(std::string foodKey, unsigned int &operations)
{
	MainStorageNode* nodePtr = storageMap->at(foodKey);
	return remove(nodePtr, operations);
}

bool MainStorage::remove(MainStorageNode* nodePtr, unsigned int &operations)
{
	bool flag = false;
	unsigned int i, n, n1, n2;
	int pos;
	std::string foodKey = StringHelper::toID(nodePtr->getname(), nodePtr->getcalorie());
	pos = storageMap->find(foodKey, operations);
	if (pos >= 0)
	{
		idBST->remove(nodePtr);
		nameFullBST->remove(nodePtr);
		List<std::string>* nameListPtr = nodePtr->getnameList();
		n1 = nameListPtr->size();
		n = (nameIndexes < n1 ? nameIndexes : n1);
		for (i = 0; i < n; i++)
		{
			nameBST[i]->remove(nodePtr);
		}
		// calorie and fat index removal
		calorieBST->remove(nodePtr);
		fatBST->remove(nodePtr);
		// carb indexes removal
		List<std::string>* carbListPtr = nodePtr->getcarbList();
		n2 = carbListPtr->size();
		n = (carbSize < n2 ? carbSize : n2);
		nameBriefBST->remove(nodePtr);
		for (i = 0; i < n; i++)
			carbBST[i]->remove(nodePtr);
		
		storageMap->remove(nodePtr, operations);
		delete nodePtr;
		flag = true;
	}
	// operations stats
	operationsTotal += operations;
	operationsDelete += operations;
	return flag;
}

bool MainStorage::update(MainStorageNode* nodePtr)
{
	return false;
}
MainStorageNode* MainStorage::getNode(std::string ID)
{
	return storageMap->at(ID);
}
HashMap <MainStorageNode*>* MainStorage::getTable()
{
	return storageMap;
}

BST<std::string, MainStorageNode>* MainStorage::getfoodnameBST()
{
	return nameBriefBST;
}

SearchResult<List<MainStorageNode*>*>* MainStorage::keyFind(std::string searchStr)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	int operations, executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	MainStorageNode* nodePtr;
	operations = 0;
	executionTime = 0;
	
	try {
		nodePtr = storageMap->at(searchStr);
		listPtr->push_back(nodePtr);
	}
	catch (const std::exception& e)
	{
		e.what();
	}
	operations++;
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}


SearchResult<List<MainStorageNode*>*>* MainStorage::idFind(int searchInt)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	operations = 0;
	executionTime = 0;
	// search
	idBST->find(searchInt, listPtr, MainStorage::accessId, operations);
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}

SearchResult<List<MainStorageNode*>*>* MainStorage::nameFind(std::string name)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	List<MainStorageNode*>* listPtrCurrent = new List<MainStorageNode*>;
	List<MainStorageNode*>* listPtrIntersectPrev = new List<MainStorageNode*>;
	List<MainStorageNode*>* listPtrIntersectCurrent = new List<MainStorageNode*>;
	operations = 0;
	executionTime = 0;
	List<std::string>* nameList = StringHelper::split(StringHelper::toLower(StringHelper::sanitize255(name)), " ");
	unsigned int i, j, n;
	n = nameList->size();
	for (i = 0; i < n; i++)
	{
		if ((*nameList)[i].length() >= 3)
		{
			listPtr->clear();
			for (j = 0; j < nameIndexes; j++)
			{
				nameBST[j]->find((*nameList)[i], listPtrCurrent, accessnameList(j), operations);
				MainStorage::mergeUnique(listPtrCurrent, listPtr, operations);
				listPtrCurrent->clear();
			}
			if (!listPtrIntersectPrev->empty())
			{
				MainStorage::intersection(listPtrIntersectPrev, listPtr, listPtrIntersectCurrent, operations);
				listPtr->clear();
				listPtr->copy(listPtrIntersectCurrent);
				listPtrIntersectCurrent->clear();
			}
			listPtrIntersectPrev->copy(listPtr);
		}
	}
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}
SearchResult<List<MainStorageNode*>*>* MainStorage::calorieFind(int searchInt)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	operations = 0;
	executionTime = 0;
	// search
	calorieBST->find(searchInt, listPtr, MainStorage::accesscalorie, operations);
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}

SearchResult<List<MainStorageNode*>*>* MainStorage::namecalorieFind(std::string name, int calorie)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	List<MainStorageNode*>* listPtr1;
	List<MainStorageNode*>* listPtr2;
	SearchResult<List<MainStorageNode*>*>* nameSearchResultPtr;
	SearchResult<List<MainStorageNode*>*>* calorieSearchResultPtr;
	operations = 0;
	executionTime = 0;
	// searches
	nameSearchResultPtr = nameFind(name);
	calorieSearchResultPtr = calorieFind(calorie);
	// search results
	listPtr1 = nameSearchResultPtr->getResults();
	operations += nameSearchResultPtr->getOperations();
	executionTime += nameSearchResultPtr->getExecutionTime();
	listPtr2 = calorieSearchResultPtr->getResults();
	operations += calorieSearchResultPtr->getOperations();
	executionTime += calorieSearchResultPtr->getExecutionTime();
	// intersect results
	intersection(listPtr1, listPtr2, listPtr, operations);
	delete listPtr1;
	delete listPtr2;
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// clock, clean-up, and return
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	delete nameSearchResultPtr;
	delete calorieSearchResultPtr;
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}
SearchResult<List<MainStorageNode*>*>* MainStorage::fatFind(double fat)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	operations = 0;
	executionTime = 0;
	// search
	fatBST->find(fat, listPtr, MainStorage::accessfat, operations);
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}
SearchResult<List<MainStorageNode*>*>* MainStorage::carbFind(std::string carb)
{
	// init vars
	std::chrono::high_resolution_clock::time_point t1 = std::chrono::high_resolution_clock::now();
	unsigned int operations;
	int executionTime;
	List<MainStorageNode*>* listPtr = new List<MainStorageNode*>;
	List<MainStorageNode*>* listPtrCurrent = new List<MainStorageNode*>;
	operations = 0;
	executionTime = 0;
	// search
	for (int i = 0; i < carbSize; i++)
	{
		carbBST[i]->find(StringHelper::toLower(carb), listPtrCurrent, accesscarb(i), operations);
		// merge unique sub result food nodes into the final result of food nodes
		MainStorage::mergeUnique(listPtrCurrent, listPtr, operations);
		listPtrCurrent->clear();
	}
	// operations stats
	operationsTotal += operations;
	operationsFind += operations;
	// search results
	std::chrono::high_resolution_clock::time_point t2 = std::chrono::high_resolution_clock::now();
	executionTime = (int)std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
	return new SearchResult<List<MainStorageNode*>*>(listPtr, operations, executionTime);
}

bool MainStorage::intersection(List<MainStorageNode*>* listPtr1, List<MainStorageNode*>* listPtr2, List<MainStorageNode*>* listPtrResult, unsigned int &operations)
{
	unsigned int i, n1;
	n1 = listPtr1->size();
	operations += 3;
	for (i = 0; i < n1; i++)
	{
		operations++;
		// list2 contains value, but resultList does not
		if (listPtr2->find((*listPtr1)[i], operations) && !listPtrResult->find((*listPtr1)[i], operations))
		{
			listPtrResult->push_back((*listPtr1)[i]);
		}
	}
	return false;
}

bool MainStorage::mergeUnique(List<MainStorageNode*>* listPtr1, List<MainStorageNode*>* listPtrResult, unsigned int &operations)
{
	unsigned int i, n1;
	n1 = listPtr1->size();
	operations += 3;
	for (i = 0; i < n1; i++)
	{
		operations++;
		// resultList does not contain
		unsigned int n = listPtrResult->size();
		if (!listPtrResult->find((*listPtr1)[i], operations))
		{
			listPtrResult->push_back((*listPtr1)[i]);
		}
	}
	return false;
}

void MainStorage::listname(std::function<std::string(MainStorageNode*)>* visit, std::string &log) {
	nameFullBST->visitLogInorder(visit, log);
}

std::string MainStorage::visit(MainStorageNode* nodePtr)
{
	// string stream would also work for non-string data
	std::stringstream ss;
	ss << nodePtr->getname() << std::endl << nodePtr->getcalorie() << std::endl;
	return ss.str();
}

std::string MainStorage::visitnameList(MainStorageNode* nodePtr)
{
	std::stringstream ss;
	List<std::string>* nameList = nodePtr->getnameList();
	int n = nameList->size();
	ss << "names: ";
	for (int i = 0; i < n; i++)
	{
		ss << (*accessnameList(i))(nodePtr) << " ";
	}
	ss << "\n";
	//std::cout << ss.str ();
	return ss.str();
}

int MainStorage::accessId(MainStorageNode* nodePtr)
{
	return nodePtr->getThefoodDBId();
}

std::string MainStorage::accessname(MainStorageNode* nodePtr)
{
	// case insensitive
	return StringHelper::toLower(nodePtr->getname());
}

std::string MainStorage::accessnameBrief(MainStorageNode* nodePtr)
{

	return nodePtr->getnameList(0).substr(0, 5);
}

std::string MainStorage::accessnameFull(MainStorageNode* nodePtr)
{
	return nodePtr->getname();
}

std::function<std::string(MainStorageNode*)>* MainStorage::accessnameList(unsigned int index)
{
	return new std::function<std::string(MainStorageNode*)>(std::bind(&accessnameListIndex, std::placeholders::_1, index));
}

std::string MainStorage::accessnameListIndex(MainStorageNode* nodePtr, unsigned int index)
{
	return nodePtr->getnameList(index);
}

int MainStorage::accesscalorie(MainStorageNode* nodePtr)
{
	return nodePtr->getcalorie();
}

double MainStorage::accessfat(MainStorageNode* nodePtr)
{
	return nodePtr->getfat();
}

std::function<std::string(MainStorageNode*)>* MainStorage::accesscarb(unsigned int index)
{
	return new std::function<std::string(MainStorageNode*)>(std::bind(&accesscarbIndex, std::placeholders::_1, index));
}

std::string MainStorage::accesscarbIndex(MainStorageNode* nodePtr, unsigned int index)
{
	// case insensitive
	return StringHelper::toLower(nodePtr->getcarb(index));
}

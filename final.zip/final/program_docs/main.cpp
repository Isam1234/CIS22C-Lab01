/**
@mainpage foodDatabase
This program will allow the user to find more information about a food.
*/
#define DEBUG_MODE false

#include "CommandLineUI.h"

int main ()
{
	CommandLineUI::enterLoop ();
	system ("pause");
	return 0;
}
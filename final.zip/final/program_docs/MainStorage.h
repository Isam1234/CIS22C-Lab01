#ifndef MAIN_STORAGE_H
#define MAIN_STORAGE_H

#include <functional>
#include <string>
#include <sstream>
#include <chrono>
#include "StringHelper.h"
#include "MainStorageNode.h"
#include "List.h"
#include "BST.h"
#include "HashMap.h"
#include "SearchResult.h"

class MainStorage
{
private:
	static const unsigned int carbSize = 2;
	static const unsigned int nameIndexes = 10;
	static const unsigned int maxItems = 1000;
	HashMap <MainStorageNode*>* storageMap;
	unsigned int itemCount, operationsTotal, operationsInsert, operationsFind, operationsDelete;
	BST<int, MainStorageNode> * idBST;
	BST<std::string, MainStorageNode> * nameBriefBST;
	BST<std::string, MainStorageNode> * nameFullBST;
	BST<std::string, MainStorageNode> ** nameBST;
	BST<int, MainStorageNode> * calorieBST;
	BST<double, MainStorageNode> * fatBST;
	BST<std::string, MainStorageNode>** carbBST;
public:
	MainStorage();

	unsigned int size() const;

	std::string insert(std::string name, int calorie, double fat, std::string protein, unsigned int &operations);

	std::string insert(MainStorageNode* nodePtr, unsigned int &operations);

	bool remove(std::string foodKey, unsigned int &operations);
	bool remove(MainStorageNode* nodePtr, unsigned int &operations);

	bool update(MainStorageNode* nodePtr);
	MainStorageNode* getNode(std::string ID);
	HashMap <MainStorageNode*>* getTable();
	BST<std::string, MainStorageNode>* getfoodnameBST();

	SearchResult<List<MainStorageNode*>*>* keyFind(std::string searchStr);
	SearchResult<List<MainStorageNode*>*>* idFind(int searchInt);
	SearchResult<List<MainStorageNode*>*>* nameFind(std::string name);
	SearchResult<List<MainStorageNode*>*>* calorieFind(int searchInt);
	SearchResult<List<MainStorageNode*>*>* namecalorieFind(std::string name, int calorie);
	SearchResult<List<MainStorageNode*>*>* fatFind(double fat);
	SearchResult<List<MainStorageNode*>*>* carbFind(std::string carb);

	static bool intersection(List<MainStorageNode*>* listPtr1, List<MainStorageNode*>* listPtr2, List<MainStorageNode*>* listPtrResult, unsigned int &operations);
	static bool mergeUnique(List<MainStorageNode*>* listPtr1, List<MainStorageNode*>* listPtrResult, unsigned int &operations);

	void listname(std::function<std::string(MainStorageNode*)>* visit, std::string &log);

	static std::string visit(MainStorageNode* nodePtr);
	static std::string visitnameList(MainStorageNode* nodePtr);
	static int MainStorage::accessId(MainStorageNode* nodePtr);
	static std::string MainStorage::accessname(MainStorageNode* nodePtr);
	static std::string MainStorage::accessnameBrief(MainStorageNode* nodePtr);
	static std::string MainStorage::accessnameFull(MainStorageNode* nodePtr);
	static std::function<std::string(MainStorageNode*)>* MainStorage::accessnameList(unsigned int index);
	static std::string MainStorage::accessnameListIndex(MainStorageNode* nodePtr, unsigned int index);
	static int MainStorage::accesscalorie(MainStorageNode* nodePtr);
	static double MainStorage::accessfat(MainStorageNode* nodePtr);
	static std::function<std::string(MainStorageNode*)>* MainStorage::accesscarb(unsigned int index);
	static std::string accesscarbIndex(MainStorageNode* nodePtr, unsigned int index);
};

#endif
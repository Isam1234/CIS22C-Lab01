#include "MathHelper.h"

int MathHelper::max (int x, int y)
{
	return x < y ? y : x;
}
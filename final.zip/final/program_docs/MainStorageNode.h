#ifndef MAIN_STORAGE_NODE_H
#define MAIN_STORAGE_NODE_H

#include <iostream>
#include <string>
#include "List.h"
#include "StringHelper.h"

class MainStorageNode
{
private:
	static const int carbSize = 2;
	static const int nameIndexes = 10;

	std::string name;
	List<std::string>* nameListPtr;

	int calorie;

	int thefoodDBId;

	double fat;

	List<std::string>* carbListPtr;
	std::string protein;
	std::string contentfat;
public:
	MainStorageNode ();
	MainStorageNode (std::string nameInit, int calorieInit, double fatInit, std::string proteinInit);

	void setcarbs (List<std::string>*);
	void setThefoodDBId (int idInit);
	void setContentfat (std::string contentfatInit);

	int MainStorageNode::getcarbSize ();
	int MainStorageNode::getnameIndexes ();

	std::string getname ();
	List<std::string>* getnameList ();
	std::string getnameList (int index);
	int getcalorie ();
	int getId();
	int getThefoodDBId ();
	double getfat ();
	List<std::string>* getcarbList ();
	std::string getcarb (int index);
	std::string getcarbStr();
	std::string getprotein();

	friend std::ostream& operator<<(std::ostream& os, const MainStorageNode* obj);
	bool MainStorageNode::operator ==(MainStorageNode &b) const;
};
#endif
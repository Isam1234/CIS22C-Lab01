#include "MainStorageNode.h"

MainStorageNode::MainStorageNode ()
{
	name = "";
	nameListPtr = new List<std::string>;
	calorie= 0;
	thefoodDBId = 0;
	fat = 10;
	protein = "";
	carbListPtr = new List<std::string>;
}

MainStorageNode::MainStorageNode (std::string nameInit, int calorieInit, double fatInit, std::string proteinInit)
{
	name = StringHelper::sanitize255 (nameInit);
	nameListPtr = StringHelper::split (StringHelper::toLower (StringHelper::sanitize (name, ' ')), " ");
	unsigned int i, n;
	n = nameListPtr->size ();
	for (i = 0; i < n; i++)
	{
		if ((*nameListPtr)[i].length () < 3)
		{
			nameListPtr->erase (i);
			i--;
			n--;
		}
	}
	thefoodDBId = 0;
	calorie = calorieInit;
	fat = fatInit;
	protein = proteinInit;
	carbListPtr = new List<std::string>;

}

void MainStorageNode::setcarbs (List<std::string>* carbListPtrInit)
{
	unsigned int i, n;
	n = carbListPtrInit->size ();
	for (i = 0; i < n; i++)
		if ((*carbListPtrInit)[i] != "")
			carbListPtr->push_back ((*carbListPtrInit)[i]);
}

void MainStorageNode::setThefoodDBId (int idInit)
{
	thefoodDBId = idInit;
}
void MainStorageNode::setContentfat (std::string contentfatInit)
{
	contentfat = contentfatInit;
}



int MainStorageNode::getcarbSize () { return carbSize; }
int MainStorageNode::getnameIndexes () { return nameIndexes; }

std::string MainStorageNode::getname () { return name; }
List<std::string>* MainStorageNode::getnameList () { return nameListPtr; }
std::string MainStorageNode::getnameList (int index) { return (*nameListPtr)[index]; }
int MainStorageNode::getcalorie () { return calorie; }
int MainStorageNode::getId() { return thefoodDBId; }
int MainStorageNode::getThefoodDBId () { return thefoodDBId; }
double MainStorageNode::getfat() { return fat; }
List<std::string>* MainStorageNode::getcarbList () { return carbListPtr; }
std::string MainStorageNode::getcarb (int index) { return (*carbListPtr)[index]; }
std::string MainStorageNode::getcarbStr() { return StringHelper::join(carbListPtr,", "); }
std::string MainStorageNode::getprotein() { return protein; }

bool MainStorageNode::operator ==(MainStorageNode &other) const
{
	return thefoodDBId == other.getThefoodDBId ();
}
#include "FileIO.h"

bool FileIO::mainStorageToFile (MainStorage *mainStoragePtr, std::string filePath, std::function<void(MainStorageNode*)>* visit, unsigned int &operations)
{
	// variable declarations
	unsigned int i, n;
	HashMap <MainStorageNode*>* foodHashMapPtr;
	HashMapNode<MainStorageNode*>* foodHashMapNodePtr;
	List<std::string>* carbListPtr;
	std::string key, serializedData;
	MainStorageNode* foodNodePtr;
	bool flag = false;

	// open file for writing
	std::ofstream myFile;
	myFile.open (filePath);
	if (myFile)
	{
		myFile << filePath << "\n";
		foodHashMapPtr = mainStoragePtr->getTable ();
		HashMap <MainStorageNode*>::iterator it;
		HashMap <MainStorageNode*>::iterator itend = foodHashMapPtr->end();
		for (it = foodHashMapPtr->begin(); it != itend; it++)
		{
			operations += 13;
			foodHashMapNodePtr = it->getSelf();
			key = foodHashMapNodePtr->getKey();
			foodNodePtr = foodHashMapNodePtr->getValue();
			(*visit)(foodNodePtr);

			serializedData = "\n*****";
			serializedData += "\n***ID: " + std::to_string(foodNodePtr->getThefoodDBId());
			serializedData += "\n***TT: " + foodNodePtr->getname();
			serializedData += "\n***CL: " + std::to_string(foodNodePtr->getcalorie());
			serializedData += "\n***FT: " + std::to_string(foodNodePtr->getfat());
			serializedData += "\n***CB:";
			carbListPtr = foodNodePtr->getcarbList();
			n = carbListPtr->size();
			for (i = 0; i < n; i++)
			{
				operations++;
				serializedData += " *" + carbListPtr->getValue(i);
			}

				serializedData += "\n***PR: " + foodNodePtr->getprotein() + "\n";
			myFile << serializedData;
		}
		myFile << "\n**********";
		flag = true;
		myFile.close();
	
	}
	return flag;
}
bool FileIO::fileToMainStorage (MainStorage *mainStoragePtr, std::string filePath, std::function<void(MainStorageNode*)>* visit, unsigned int &operations)
{
	std::string key, name, protein, carb, path, readIn, word;
	int calorie, thefoodDBId;
	double fat;
	bool flag = false;
	std::ifstream myFile;
	MainStorageNode* foodNodePtr;
	List<std::string>* carbListPtr = new List<std::string> ();
	
	myFile.open (filePath);
	if (myFile.is_open ())
	{
		flag = true;
		std::getline(myFile, path); // *
#if DEBUG_MODE
		std::cout << path << std::endl;
#endif
		while (myFile.good ())
		{
			std::getline(myFile, readIn); 
#if DEBUG_MODE
			std::cout << readIn << std::endl;
#endif
			std::getline(myFile, readIn); // *
#if DEBUG_MODE
			std::cout << readIn << std::endl;
#endif
			
			if (readIn == "**********")
			{
				myFile.close();
				return flag;
			}

			std::getline(myFile, readIn);
			std::istringstream iss(readIn);
			iss >> word;
			if(word != "***ID:")
				throw std::runtime_error("The database file is invalid: ID");
			iss >> readIn;
			thefoodDBId = std::stoi(readIn);

			std::getline(myFile, readIn);
			std::istringstream iss2(readIn);
			iss2 >> word;
			if(word != "***TT:")
				throw std::runtime_error("The database file is invalid: TT");
			name = iss2.str();
			name = name.substr(7, std::string::npos);

			std::getline(myFile, readIn);
			std::istringstream iss6(readIn);
			iss6 >> word;
			if (word != "***CL:")
				throw std::runtime_error("The database file is invalid: CL");
			iss6 >> readIn;
			calorie = std::stoi(readIn);

			std::getline(myFile, readIn);
			std::istringstream iss3(readIn);
			iss3 >> word;
			if (word != "***FT:")
				throw std::runtime_error("The database file is invalid: FT");
			iss3 >> readIn;
			fat = std::stod(readIn);

		
			std::getline(myFile, readIn);
#if DEBUG_MODE
			std::cout << readIn << std::endl;
#endif
			std::istringstream iss4(readIn);
			iss4 >> word;
			if(word != "***CB:")
				throw std::runtime_error("The database file is invalid: CB");
			
			operations += 25;
			while (iss4 >> readIn)
			{
#if DEBUG_MODE
				std::cout << readIn << std::endl;
#endif
				operations++;
				if (readIn.at(0) == '*')
				{
					if (carb.length() > 1)
					{
						carbListPtr->push_back(carb);
						carb = readIn.substr(1, std::string::npos);
					}
					else
					{
						carb = readIn.substr(1, std::string::npos);
					}
				}
				else
				{
					carb += " " + readIn;
					carbListPtr->push_back(carb);
					carb = "";
				}
			}
			carbListPtr->push_back(carb);
			carb = "";

		
			std::getline(myFile, readIn);
			std::istringstream iss5(readIn);
			iss5 >> word;
			if (word != "***PR:")
				throw std::runtime_error("The database file is invalid: PR");
			protein = iss5.str();
			protein = protein.substr(7, std::string::npos);

			foodNodePtr = new MainStorageNode (name, calorie, fat, protein);
			foodNodePtr->setcarbs (carbListPtr);
			carbListPtr->clear ();
			foodNodePtr->setThefoodDBId(thefoodDBId);
			// insert into the food database
			mainStoragePtr->insert (foodNodePtr, operations);
			(*visit)(foodNodePtr);
		}
		myFile.close ();
	}
	return flag;
}
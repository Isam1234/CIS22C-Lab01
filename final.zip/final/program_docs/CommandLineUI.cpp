#include "commandLineUI.h"

MainStorage* CommandLineUI::mainStoragePtr;
unsigned int CommandLineUI::operationsTotal = 0;
unsigned int CommandLineUI::operationsInsert = 0;
unsigned int CommandLineUI::operationsFind = 0;
unsigned int CommandLineUI::operationsDelete = 0;

std::string CommandLineUI::initialFilePath = "mainStorage.txt";

void CommandLineUI::enterLoop()
{
	mainStoragePtr = new MainStorage;
	int menuOption;
	unsigned int operations, n;
	bool flag;
	operations = 0;

	std::cout << "Starting program..." << std::endl << std::endl << "Importing Data";
	try
	{
		flag = FileIO::fileToMainStorage(mainStoragePtr, initialFilePath, new std::function<void(MainStorageNode*)>(&visitImportDot), operations);
		operationsTotal += operations;
		operationsInsert += operations;
	}
	catch (const std::exception& e)
	{
		std::cout << "Error: " << e.what() << std::endl;
	}
	if (flag)
	{
		n = mainStoragePtr->size();
		std::cout << std::endl;
		std::cout << "Total Foods Cached: " << n << std::endl;
		std::cout << "Operations Performed: " << operations << " (" << ((n == 0) ? operations : (operations / n)) << " operations per food item)" << std::endl << std::endl;
	}
	// begin loop
	bool loopActive = true;
	while (loopActive)
	{
		std::cout << "Enter the number for which options you want to take below:" << std::endl
			<< "1. Add food" << std::endl
			<< "2. Delete food by food ID or food key" << std::endl
			<< "3. Find food by food ID or food key" << std::endl
			<< "4. Hash Table Statistics" << std::endl
			<< "5. food names in alphabetical order" << std::endl
			<< "6. Display food name BST" << std::endl
			<< "7. Efficiency" << std::endl
			<< "8. Import food Storage File" << std::endl
			<< "9. Export food Storage File" << std::endl
			<< "10. Search food Locally by name" << std::endl
			<< "11. Search food Locally by carb" << std::endl

			<< "12. Update food by food ID or food key" << std::endl

			<< "13. Exit Program" << std::endl << std::endl
			<< "Selection Number: ";
		std::cin >> menuOption;
		if (std::cin.fail())
		{
			std::cin.clear(); // clears failure state
			std::cin.ignore(999, '\n'); // discards "bad" characters
			//std::cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n'); // discards "bad" characters
			menuOption = 0;
		}
		std::cout << std::endl;
		if (menuOption < 1 || menuOption > 13)
		{
			std::cout << "************************************" << std::endl;
			std::cout << "Your selection was not valid. Please try again." << std::endl;
			std::cout << "************************************" << std::endl << std::endl;
		}
		else
		{
			if (menuOption == 1) addfood();
			else if (menuOption == 2) deletefood();
			else if (menuOption == 3) findfood();
			else if (menuOption == 4) HashMapStats();
			else if (menuOption == 5) listname();
			else if (menuOption == 6) printfoodnameBST();
			else if (menuOption == 7) efficiencyStats();
			else if (menuOption == 8) importFile();
			else if (menuOption == 9) fileExport();
			else if (menuOption == 10) nameSearch();
			else if (menuOption == 11) carbSearch();
			else if (menuOption == 12) updatefood();
			else if (menuOption == 13) loopActive = false;
		}
	}
}



void CommandLineUI::nameSearch()
{
	std::string searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	std::cout << std::endl << "Local food Database search" << std::endl
		<< "Enter the name of the food: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, searchTerm);
	std::cout << "Searching for: " << std::endl
		<< "name: " << searchTerm << std::endl << std::endl;
	searchResultPtr = mainStoragePtr->nameFind(searchTerm);
	/* display search statistics and results */
	searchResultHelper(searchResultPtr);
}

void CommandLineUI::importFile()
{
	std::string filePath;
	bool flag = false;
	List<MainStorageNode*>* resultNodesPtr = new List<MainStorageNode*>;
	unsigned int operations = 0;
	std::cout << std::endl << "Import food Database File" << std::endl
		<< "Enter the file path: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, filePath);
	std::cout << "Importing file...: " << std::endl
		<< "Path: " << filePath << std::endl << std::endl;
	// file import
	std::cout << "Importing Data";
	try
	{
		flag = FileIO::fileToMainStorage(mainStoragePtr, filePath, new std::function<void(MainStorageNode*)>(&visitImportDot), operations);
		operationsTotal += operations;
		operationsInsert += operations;
	}
	catch (const std::exception& e)
	{
		std::cout << "Error: " << e.what() << std::endl;
	}
	if (flag)
	{
		std::cout << std::endl;
		std::cout << "foods Imported Successfully!" << std::endl;
		std::cout << "Total foods Cached: " << mainStoragePtr->size() << std::endl;
		std::cout << "Operations Performed: " << operations << std::endl;
	}
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::fileExport()
{
	std::string filePath;
	bool flag = false;
	List<MainStorageNode*>* resultNodesPtr = new List<MainStorageNode*>;
	unsigned int operations = 0;
	std::cout << std::endl << "Export Food Database File" << std::endl
		<< "Enter the file path: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, filePath);
	std::cout << "Exporting file...: " << std::endl
		<< "Path: " << filePath << std::endl << std::endl;
	// file export
	std::cout << "Exporting Data";
	try
	{
		flag = FileIO::mainStorageToFile(mainStoragePtr, filePath, new std::function<void(MainStorageNode*)>(&visitExportDot), operations);
		operationsTotal += operations;
	}
	catch (const std::exception& e)
	{
		std::cout << "Error: " << e.what() << std::endl;
	}
	if (flag)
	{
		std::cout << std::endl;
		std::cout << "Foods Exporteded Successfully!" << std::endl;
		std::cout << "Total foods cached: " << mainStoragePtr->size() << std::endl;
		std::cout << "Operations Performed: " << operations << std::endl;
	}
	std::cout << "______________________________________________" << std::endl;
}



void CommandLineUI::fatSearch()
{
	double searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	std::cout << std::endl << "Local food Database search" << std::endl
		<< "Enter the amount of fat: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::cin >> searchTerm;
	std::cout << "Searching for: " << std::endl
		<< "fat: " << std::to_string(searchTerm) << std::endl << std::endl;
	searchResultPtr = mainStoragePtr->fatFind(searchTerm);
	/* display search statistics and results */
	searchResultHelper(searchResultPtr);
}

void CommandLineUI::carbSearch()
{
	std::string searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	std::cout << std::endl << "Local food Database search" << std::endl
		<< "Enter the carb: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, searchTerm);
	std::cout << "Searching for: " << std::endl
		<< "carb: " << searchTerm << std::endl << std::endl;
	searchResultPtr = mainStoragePtr->carbFind(searchTerm);
	/* display search statistics and results */
	searchResultHelper(searchResultPtr);
}

void CommandLineUI::addfood()
{
	unsigned int foodId, calorie, operations;
	double fat;
	MainStorageNode* foodNodePtr;
	List<std::string>* carbListPtr;
	std::string name, protein, carbStr;
	foodId = 0;
	calorie = 0;
	fat = 0.0;
	operations = 0;
	bool foodIdValid, calorieValid, fatValid;
	foodIdValid = calorieValid = fatValid = false;
	std::cout << std::endl << "Add food" << std::endl;
	while (std::cin.fail() || !foodIdValid)
	{
		std::cout << "Enter the food ID: ";
		std::cin >> foodId;
		foodIdValid = (foodId > 0 && mainStoragePtr->idFind(foodId)->getResults()->size() == 0);
		if (std::cin.fail()) {
			std::cout << "************************************" << std::endl;
			std::cout << "Invalid characters. Must be int. Please try again." << std::endl;
			std::cout << "************************************" << std::endl << std::endl;
			std::cin.clear(); // clears failure state
			std::cin.ignore(999, '\n'); // discards "bad" characters
										//std::cin.ignore (std::numeric_limits<std::streamsize>::max (), '\n'); // discards "bad" characters
			foodId = 0;
		}
		else if (!foodIdValid) {
			std::cout << "************************************" << std::endl;
			std::cout << "That food ID has already been taken. Please try again." << std::endl;
			std::cout << "************************************" << std::endl << std::endl;
		}
	}
	std::cin.clear(); // clears failure state
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::cout << "Enter the name of the food: ";
	std::getline(std::cin, name);
	while (std::cin.fail() || !calorieValid)
	{
		std::cout << "Enter the calorie count: ";
		std::cin >> calorie;
		calorieValid = (calorie > 0 && calorie < 9999);
		if (std::cin.fail()) {
			std::cout << "************************************" << std::endl;
			std::cout << "Invalid characters. Must be int. Please try again." << std::endl;
			std::cout << "************************************" << std::endl << std::endl;
			std::cin.clear(); // clears failure state
			std::cin.ignore(999, '\n'); // discards "bad" characters
			calorie = 0;
		}
	}
	while (std::cin.fail() || !fatValid)
	{
		std::cout << "Enter the amount of fat: ";
		std::cin >> fat;
		fatValid = (fat >= 0 && fat <= 10);
		if (std::cin.fail()) {
			std::cout << "************************************" << std::endl;
			std::cout << "Invalid characters. Must be double. Please try again." << std::endl;
			std::cout << "************************************" << std::endl << std::endl;
			std::cin.clear(); // clears failure state
			std::cin.ignore(999, '\n'); // discards "bad" characters
			fat = 0.0;
		}
	}
	std::cin.clear(); // clears failure state
	std::cin.ignore(999, '\n'); // discards "bad" characters
	// take user input for carb string and parse into a list
	std::cout << "Enter the amount of carbs separated by a comma ',': ";
	std::getline(std::cin, carbStr);
	carbListPtr = StringHelper::split(carbStr, ",");
	StringHelper::reduce(carbListPtr); // trim and remove excessive whitespace to each element
	std::cout << "Enter the amount of protein: ";
	std::getline(std::cin, protein);
	std::cout << "Adding new food: " << std::endl
		<< "Food ID: " << foodId << std::endl
		<< "name: " << name << std::endl << std::endl;
	// create the node
	foodNodePtr = new MainStorageNode(name, calorie, fat, protein);
	foodNodePtr->setcarbs(carbListPtr);
	carbListPtr->clear();
	foodNodePtr->setThefoodDBId(foodId);
	// insert
	mainStoragePtr->insert(foodNodePtr, operations);
	operationsTotal += operations;
	operationsInsert += operations;
	std::cout << "Food Insertion Done! " << std::endl;
	std::cout << "Operations Performed: " << operations << std::endl;
	std::cout << "Total foods Cached: " << mainStoragePtr->size() << std::endl;
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::deletefood()
{
	std::string searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	std::cout << std::endl << "Delete food" << std::endl
		<< "Enter the food ID or Hash Table Key: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, searchTerm);
	if (searchTerm != "") {
		if (StringHelper::isNumeric(searchTerm)) {
			// search the term as the food ID
			int targetID;
			targetID = std::stoi(searchTerm);
			std::cout << "Searching for and Deleteing: " << std::endl
				<< "food ID: " << targetID << std::endl << std::endl;
			searchResultPtr = mainStoragePtr->idFind(targetID);
		}
		else
		{
			// search the term as the hash table key
			std::cout << "Searching for and Deleteing: " << std::endl
				<< "Hash Table Key: " << searchTerm << std::endl << std::endl;
			searchResultPtr = mainStoragePtr->keyFind(searchTerm);
		}
		/* delete results */
		deleteResultHelper(searchResultPtr);
	}
	else {
		std::cout << "Input may not be empty!" << std::endl;
		std::cout << "______________________________________________" << std::endl;
	}
}

void CommandLineUI::updatefood()
{
	std::string searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	List<MainStorageNode*>* nodeListPtr;
	MainStorageNode *foodNodePtr, *targetNodePtr;
	unsigned int foodId, foodIdOrig, calorie, calorieOrig, operations, executionTime, n;
	double fat, fatOrig;
	List<std::string>* carbListPtr;
	std::string name, nameOrig, foodIdStr, calorieStr, fatStr, protein, proteinOrig, carbStr, carbStrOrig;
	bool foodIdValid, calorieValid, fatValid;
	foodIdValid = calorieValid = fatValid = false;
	std::cout << std::endl << "Update A Food" << std::endl;
	// get by ID or hash key
	std::cout << "Enter the Food ID or Hash Table Key: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, searchTerm);
	if (searchTerm != "") {
		if (StringHelper::isNumeric(searchTerm)) {
			// search the term as the food ID
			int targetID;
			targetID = std::stoi(searchTerm);
			std::cout << "Searching for: " << std::endl
				<< "food ID: " << targetID << std::endl << std::endl;
			searchResultPtr = mainStoragePtr->idFind(targetID);
		}
		else
		{
			// search the term as the hash table key
			std::cout << "Searching for: " << std::endl
				<< "Hash Table Key: " << searchTerm << std::endl << std::endl;
			searchResultPtr = mainStoragePtr->keyFind(searchTerm);
		}
		nodeListPtr = searchResultPtr->getResults();
		operations = searchResultPtr->getOperations();
		executionTime = (unsigned int)searchResultPtr->getExecutionTime();
		n = nodeListPtr->size();
		// food to edit found. Only want one result.
		if (n == 1) {
			std::cout << (*nodeListPtr)[0] << std::endl;
			std::cout << "EDIT HAS BEGUN. ENTER A BLANK TO KEEP ORIGINAL VALUE. DO NOT TYPE A SPACE." << std::endl;
			targetNodePtr = (*nodeListPtr)[0];
			foodId = foodIdOrig = targetNodePtr->getId();
			name = nameOrig = targetNodePtr->getname();
			calorie = calorieOrig = targetNodePtr->getcalorie();
			fat = fatOrig = targetNodePtr->getfat();
			carbStr = carbStrOrig = targetNodePtr->getcarbStr();
			protein = proteinOrig = targetNodePtr->getprotein();
			// Auto fill variables with data from the searched food node
			while (!foodIdValid)
			{
				std::cout << "Enter the food new ID: ";
				std::getline(std::cin, foodIdStr);
				if (foodIdStr == "") {
					foodIdValid = true;
					foodId = foodIdOrig;
				}
				else if (StringHelper::isNumeric(foodIdStr)) {
					foodId = stoi(foodIdStr);
				}
				else {
					foodId = 0;
				}
				foodIdValid = (foodIdOrig == foodId || (foodId > 0 && mainStoragePtr->idFind(foodId)->getResults()->size() == 0));
				if (!foodIdValid) {
					std::cout << "************************************" << std::endl;
					std::cout << "That food ID has already been taken. Please try again." << std::endl;
					std::cout << "************************************" << std::endl << std::endl;
				}
			}
			std::cout << "Enter the name: ";
			std::getline(std::cin, name);
			if (name == "") {
				name = nameOrig;
			}
			while (std::cin.fail() || !calorieValid)
			{
				if (std::cin.fail()) {
					std::cout << "************************************" << std::endl;
					std::cout << "Invalid characters. Must be int. Please try again." << std::endl;
					std::cout << "************************************" << std::endl << std::endl;
					std::cin.clear(); // clears failure state
					std::cin.ignore(999, '\n'); // discards "bad" characters
				}
				std::cout << "Enter the new calorie: ";
				std::getline(std::cin, calorieStr);
				if (calorieStr == "") {
					calorieValid = true;
					calorie = calorieOrig;
				}
				else if (StringHelper::isNumeric(calorieStr) && calorieStr.length() <= 4) {
					calorie = stoi(calorieStr);
				}
				else {
					calorie = 0;
				}
				calorieValid = (calorie > 0);
			}
			while (std::cin.fail() || !fatValid)
			{
				if (std::cin.fail()) {
					std::cout << "************************************" << std::endl;
					std::cout << "Invalid characters. Must be double. Please try again." << std::endl;
					std::cout << "************************************" << std::endl << std::endl;
					std::cin.clear(); // clears failure state
					std::cin.ignore(999, '\n'); // discards "bad" characters
				}
				std::cout << "Enter the amount of fat: ";
				std::getline(std::cin, fatStr);
				if (fatStr == "") {
					fatValid = true;
					fat = fatOrig;
				}
				else if (StringHelper::isNumeric(fatStr) && calorieStr.length() <= 3) {
					fat = stod(fatStr);
				}
				else {
					fat = 999;
				}
				fatValid = (fat >= 0 && fat <= 10);
			}

			std::cout << "Enter the amount of carbs separated by a comma ',': ";
			std::getline(std::cin, carbStr);
			if (carbStr == "") {
				carbStr = carbStrOrig;
			}
			carbListPtr = StringHelper::split(carbStr, ",");
			StringHelper::reduce(carbListPtr); 
	
			std::cout << "Enter the amount of protein: ";
			std::getline(std::cin, protein);
			if (protein == "") {
				protein = proteinOrig;
			}
			std::cout << "Editing food: " << std::endl
				<< "food ID: " << foodId << std::endl
				<< "name: " << name << std::endl << std::endl;
			// create the node
			foodNodePtr = new MainStorageNode(name, calorie, fat, protein);
			foodNodePtr->setcarbs(carbListPtr);
			carbListPtr->clear();
			foodNodePtr->setThefoodDBId(foodId);
			// remove
			mainStoragePtr->remove(targetNodePtr, operations);
			// insert
			mainStoragePtr->insert(foodNodePtr, operations);
			operationsTotal += operations;
			operationsInsert += operations;
			std::cout << "food Update Done! " << std::endl;
			std::cout << "Operations Performed: " << operations << std::endl;
			std::cout << "Total foods Cached: " << mainStoragePtr->size() << std::endl;
			std::cout << "______________________________________________" << std::endl;
		}
		else {
			std::cout << "food not found!" << std::endl;
			std::cout << "______________________________________________" << std::endl;
		}
	}
	else {
		std::cout << "Input may not be empty!" << std::endl;
		std::cout << "______________________________________________" << std::endl;
	}
}

void CommandLineUI::findfood()
{
	std::string searchTerm;
	SearchResult<List<MainStorageNode*>*>* searchResultPtr;
	std::cout << std::endl << "Find food" << std::endl
		<< "Enter the food ID or Hash Table Key: ";
	std::cin.ignore(999, '\n'); // discards "bad" characters
	std::getline(std::cin, searchTerm);
	if (StringHelper::isNumeric(searchTerm)) {
		// search the term as the food ID
		int targetID;
		targetID = std::stoi(searchTerm);
		std::cout << "Searching for: " << std::endl
			<< "food ID: " << targetID << std::endl << std::endl;
		searchResultPtr = mainStoragePtr->idFind(targetID);
	}
	else
	{
		// search the term as the hash table key
		std::cout << "Searching for: " << std::endl
			<< "Hash Table Key: " << searchTerm << std::endl << std::endl;
		searchResultPtr = mainStoragePtr->keyFind(searchTerm);
	}
	/* display search statistics and results */
	searchResultHelper(searchResultPtr);
}

void CommandLineUI::printfoodnameBST()
{
	BST<std::string, MainStorageNode>* nameBriefBST = mainStoragePtr->getfoodnameBST();
	std::string log = "";
	nameBriefBST->logLevel(new std::function<std::string(MainStorageNode*)>(MainStorage::accessnameBrief), log);
	std::cout << std::endl << "name Name BST:" << std::endl;
	std::cout << log;
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::HashMapStats()
{
	// variable declarations
	unsigned int hashId, listPos;
	HashMap <MainStorageNode*>* foodHashMapPtr;
	HashMapNode<MainStorageNode*>* foodHashMapNodePtr;
	std::string foodKey;
	MainStorageNode* foodNodePtr;
	double loadFactor;
	bool flagCollision;
	// headers
	std::cout << std::left << std::setw(7) << "ID" << std::setw(17) << "food"
		<< std::setw(5) << "calorie" << std::setw(24) << "Key" << std::setw(5) << "Hash"
		<< std::setw(2) << "X" << std::setw(4) << "Pos" << std::endl;
	// get the entire food hash table
	foodHashMapPtr = mainStoragePtr->getTable();
	// custom iterator saves lots of nested loops
	HashMap <MainStorageNode*>::iterator it;
	HashMap <MainStorageNode*>::iterator itend = foodHashMapPtr->end();
	for (it = foodHashMapPtr->begin(); it != itend; it++)
	{
		// get the hash table nodes from the list
		foodHashMapNodePtr = it->getSelf();
		hashId = foodHashMapNodePtr->getId();
		flagCollision = foodHashMapNodePtr->isCollision();
		listPos = foodHashMapNodePtr->getListPos();
		foodKey = foodHashMapNodePtr->getKey();
		foodNodePtr = foodHashMapNodePtr->getValue();
		std::cout << std::left << std::setw(7) << foodNodePtr->getThefoodDBId() << std::setw(17) << foodNodePtr->getname().substr(0, 16)
			<< std::setw(5) << foodNodePtr->getcalorie() << std::setw(24) << foodKey.substr(0, 23) << std::setw(5) << hashId
			<< std::setw(2) << (flagCollision ? "X" : "") << std::setw(4) << listPos << std::endl;
	}
	// hash map statistics
	loadFactor = ((double)foodHashMapPtr->bucketsUsed() / (double)foodHashMapPtr->max_size()) * 100.00;
	std::cout << std::endl << "Hash Table Stats" << std::endl;
	std::cout << "Max Size: " << foodHashMapPtr->max_size() << std::endl;
	std::cout << "Load Factor: " << std::fixed << std::setprecision(0) << loadFactor << "%" << std::endl;
	std::cout << "Collision Count: " << foodHashMapPtr->collisions() << std::endl;
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::efficiencyStats() {
	std::cout << std::endl << "Efficiency Stats:" << std::endl;
	std::cout << "Total Operations: " << operationsTotal << std::endl;
	std::cout << "Insert Operations: " << operationsInsert << " (" << (int)(((double)operationsInsert / (double)operationsTotal)*100.0) << "%)" << std::endl;
	std::cout << "Find Operations: " << operationsFind << " (" << (int)(((double)operationsFind / (double)operationsTotal)*100.0) << "%)" << std::endl;
	std::cout << "Delete Operations: " << operationsDelete << " (" << (int)(((double)operationsDelete / (double)operationsTotal)*100.0) << "%)" << std::endl;
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::HashMapTest()
{
	unsigned int i, n, n1, operations;
	n = 5;
	n1 = 6;
	std::string foodKey;
	int hash;
	double loadFactor;
	HashMap <std::string>* storageMap;
	storageMap = new HashMap <std::string>(n);
	std::string nameArray[] = { "Potato","Chicken","Turkey", "Blueberry","Apple", "Banana" };
	int calorieArray[] = { 523,432,123,987,405,324 };
	std::cout << std::left << std::setw(14) << "food" << std::setw(5) << "calorie" << std::setw(20) << "Key" << std::setw(5) << "Hash" << std::endl;
	for (i = 0; i < n1; i++)
	{
		foodKey = StringHelper::toID(nameArray[i], calorieArray[i]);
		hash = StringHelper::hashStr(foodKey, n);
		std::cout << std::left << std::setw(14) << nameArray[i] << std::setw(5) << calorieArray[i] << std::setw(20) << foodKey << std::setw(5) << hash << std::endl;
		storageMap->insert(foodKey, nameArray[i], operations);
	}
	loadFactor = ((double)storageMap->bucketsUsed() / (double)storageMap->max_size()) * 100.00;
	std::cout << std::endl << "Hash Table Stats" << std::endl;
	std::cout << "Max Size: " << storageMap->max_size() << std::endl;
	std::cout << "Load Factor: " << std::fixed << std::setprecision(0) << loadFactor << "%" << std::endl;
	std::cout << "Collision Count: " << storageMap->collisions() << std::endl;
	std::cout << "______________________________________________" << std::endl;
}

void CommandLineUI::listname()
{
	std::string log;
	std::cout << std::endl << "Food names in Alphabetical Order" << std::endl;
	std::cout << std::left << std::setw(7) << "ID" << std::setw(5) << "calorie" << "food" << std::endl;
	std::cout << "______________________________________________" << std::endl;
	mainStoragePtr->listname(new std::function<std::string(MainStorageNode*)>(&visitname), log);
	std::cout << "______________________________________________" << std::endl << std::endl;
}

void CommandLineUI::addResultHelper(SearchResult<List<MainStorageNode*>*>* searchResultPtr)
{
	if (searchResultPtr)
	{
		unsigned int i, n1;
		List<MainStorageNode*>* nodeListPtr;
		nodeListPtr = searchResultPtr->getResults();
		n1 = nodeListPtr->size();
		for (i = 0; i < n1; i++)
		{
			mainStoragePtr->insert((*nodeListPtr)[i], searchResultPtr->getOperations());
		}
	}
}

void CommandLineUI::searchResultHelper(SearchResult<List<MainStorageNode*>*>* searchResultPtr)
{
	bool flag = false;
	if (searchResultPtr)
	{
		unsigned int i, n, n1, operations, executionTime;
		List<MainStorageNode*>* nodeListPtr;
		nodeListPtr = searchResultPtr->getResults();
		operations = searchResultPtr->getOperations();
		executionTime = searchResultPtr->getExecutionTime();
		n1 = nodeListPtr->size();
		n = resultsMax <= n1 ? resultsMax : n1;
		operationsTotal += operations;
		operationsFind += operations;
		std::cout << "Operations Performed: " << operations << " in " << timeSecondFormat(executionTime) << std::endl
			<< "Displaying Results: " << n << " of " << n1 << std::endl;
		std::cout << "Total foods Cached: " << mainStoragePtr->size() << std::endl;
		if (n1 > 0)
		{
			flag = true;
			std::cout << "______________________________________________" << std::endl;
			for (i = 0; i < n; i++)
			{
				std::cout << (*nodeListPtr)[i];
				if (i != n - 1) std::cout << std::endl;
			}
			std::cout << "______________________________________________" << std::endl << std::endl;
		}
	}
	// result error or no results
	if (!flag)
	{
		std::cout << "______________________________________________" << std::endl;
		std::cout << "NO RESULTS FOUND" << std::endl;
		std::cout << "______________________________________________" << std::endl << std::endl;
	}
}

void CommandLineUI::deleteResultHelper(SearchResult<List<MainStorageNode*>*>* searchResultPtr)
{
	bool flag = false;
	if (searchResultPtr)
	{
		unsigned int i, n1, operations, executionTime;
		List<MainStorageNode*>* nodeListPtr;
		nodeListPtr = searchResultPtr->getResults();
		operations = searchResultPtr->getOperations();
		executionTime = searchResultPtr->getExecutionTime();
		n1 = nodeListPtr->size();
		// begin deleting if any
		if (n1 > 0)
		{
			flag = true;
			for (i = 0; i < n1; i++)
			{
				mainStoragePtr->remove((*nodeListPtr)[i], operations);
				std::cout << "Food Node Deleted!" << std::endl;
			}
		}
		operationsTotal += operations;
		operationsDelete += operations;
		std::cout << "Operations Performed: " << operations << " in " << timeSecondFormat(executionTime) << std::endl;
		std::cout << "Total foods Cached: " << mainStoragePtr->size() << std::endl;
		std::cout << "______________________________________________" << std::endl << std::endl;
	}
	// result error or no results
	if (!flag)
	{
		std::cout << "NO RESULTS FOUND. Nothing deleted." << std::endl;
		std::cout << "______________________________________________" << std::endl << std::endl;
	}
}

void CommandLineUI::visitImport(MainStorageNode* foodNodePtr)
{
	std::cout << "Imported: " << foodNodePtr->getname() << std::endl;
}

void CommandLineUI::visitImportDot(MainStorageNode* foodNodePtr)
{
	std::cout << ".";
}

void CommandLineUI::visitExport(MainStorageNode* foodNodePtr)
{
	std::cout << "Exported: " << foodNodePtr->getname() << std::endl;
}

void CommandLineUI::visitExportDot(MainStorageNode* foodNodePtr)
{
	std::cout << ".";
}

std::string CommandLineUI::visitname(MainStorageNode* foodNodePtr)
{
	std::stringstream ss;
	ss << std::left << std::setw(7) << foodNodePtr->getId() << std::setw(5) << foodNodePtr->getcalorie() << foodNodePtr->getname() << std::endl;
	std::cout << ss.str();
	return ss.str();
}

std::string CommandLineUI::timeSecondFormat(unsigned int microSeconds) {
	std::stringstream ss;
	if (microSeconds < 1000) {
		ss << microSeconds << " microseconds";
	}
	else if (microSeconds < 1000000) {
		ss << (unsigned int)(microSeconds / 1000) << " milliseconds";
	}
	else {
		ss << (unsigned int)(microSeconds / 1000000) << " seconds";
	}
	return ss.str();
}


std::ostream& operator<<(std::ostream& os, const MainStorageNode* obj)
{
	os << "#" << obj->thefoodDBId << " name: " << obj->name;
	if (obj->calorie > 0)
		os << ", calorie: " << obj->calorie;
	if (obj->fat > 0)
		os << ", fat: " << obj->fat;
	os << std::endl;
	int n = obj->carbListPtr->size();
	if (n > 0)
	{
		os << "carb: ";
		for (int i = 0; i < n; i++)
		{
			os << obj->carbListPtr->getValue(i);
			if (i != n - 1) os << ", ";
		}
		os << std::endl;
	}
	if (obj->protein.length() > 20)
		os << "protein: " << obj->protein.substr(0, 19) << "..." << std::endl;
	else if (obj->protein.length() > 0)
		os << "protein: " << obj->protein << std::endl;
	return os;
}

template <class T>
std::ostream& operator<< (std::ostream &foo, List<T> *ListPtr)
{
	int n = ListPtr->size();
	for (int i = 0; i < n; i++)
	{
		foo << (*ListPtr)[i] << std::endl;
	}
	return foo;
}
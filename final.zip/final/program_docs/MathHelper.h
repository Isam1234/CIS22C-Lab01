#ifndef MATH_HELPER_H
#define MATH_HELPER_H

/**
@class MathHelper
A collection of static mathematic methods
*/
class MathHelper
{
public:
	static int max (int x, int y);
};
#endif
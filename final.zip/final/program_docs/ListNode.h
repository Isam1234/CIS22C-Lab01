#ifndef LIST_NODE_H
#define LIST_NODE_H

template <class T>
class ListNode
{
private:
	T value;
	ListNode<T> *next;
public:
	// CONSTRUCTORS/DESTRUCTORS
	ListNode (T nodeValue);
	~ListNode ();
	// GETTER/SETTER   
	T getValue ();
	ListNode<T>* getNext ();
	void setValue (T val);
	void setNext (ListNode<T>* nodePtr);
};

template <class T> 
ListNode<T>::ListNode (T nodeValue) // Default Constructor     
{
	value = nodeValue;
	next = nullptr;
}

template <class T>
ListNode<T>::~ListNode () // Destructor  
{
	next = nullptr;
}

template <class T>
T ListNode<T>::getValue () { return value; }

template <class T>
ListNode<T>* ListNode<T>::getNext () { return next; }

template <class T>
void ListNode<T>::setValue (T val) { value = val; }

template <class T>
void ListNode<T>::setNext (ListNode<T>* nodePtr) { next = nodePtr; }
#endif